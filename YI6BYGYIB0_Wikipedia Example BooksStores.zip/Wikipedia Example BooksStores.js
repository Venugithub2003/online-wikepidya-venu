let searchInput = document.getElementById("searchInput");
let searchResults = document.getElementById("searchResults");

function createAndAppendSearchResults(results) {
    // object diStractureing //
    let {
        author,
        imageLink,
        title
    } = results;
    // create paragraph  //
    let para = document.createElement("p");
    para.textContent = author;
    searchResults.appendChild(para);
    // create Image Element //
    let imagesrc = document.createElement("img");
    imagesrc.src = imageLink;
    searchResults.appendChild(imagesrc);
    // break Elemt //
    let breakElemt = document.createElement("br");
    searchInput.appendChild(breakElemt);
    //Tittle Element  //
    let tittle = document.createElement("a");
    tittle.textContent = title;
    tittle.href = imageLink;
    tittle.target = "_blank";
    searchResults.appendChild(tittle);
}

function displayresults(search_results) {
    for (let results of search_results) {
        createAndAppendSearchResults(results);
    }
}

function search(event) {
    if (event.key === "Enter") {
        searchResults.textContent = "";
        let searchInputE1 = searchInput.value;

        console.log(searchInputE1);
        let url = "https://apis.ccbp.in/book-store?title=" + searchInput.value;
        let options = {
            method: "GET"
        }
        fetch(url, options)
            .then(function(response) {
                return response.json();
            })
            .then(function(jsonData) {
                console.log(jsonData); // use jsonData.content instead
                let {
                    search_results
                } = jsonData;
                displayresults(search_results);
            });
    }
}
searchInput.addEventListener("keydown", search);

// here onWards will be Wrong Answer    .....//








/*
function texturl(computertext) {
    texttec.textContent = computertext.content;

}



// request get for Http  //
let options = {
    method: "GET"
};

let url = "https://apis.ccbp.in/book-store";
fetch(url, options)
    .then(function(response) {
        return response.json();
    })
    .then(function(jsonData) {
        console.log(jsonData); // use jsonData.content instead

        let computertext = jsonData;
        texturl(computertext)

    });

*/